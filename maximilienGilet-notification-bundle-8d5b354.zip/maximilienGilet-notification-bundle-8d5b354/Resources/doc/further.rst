========================
MgiletNotificationBundle
========================
------------------------------------------------
A simple Symfony 3 bundle for user notifications
------------------------------------------------

Go further
==========

If you like my bundle and/or want to :

* Suggest something
* Report a problem
* Improve something
* Add translation(s)

Just go to the project's `Github`_. :)

Most important thing : if you like it share it !

Thanks
~~~~~~

A huge thanks to the Symfony community and all amazing free piece of software.

And thank you for using this.

----------------------------------------------

* `installation`_

* `basic usage`_

* `overriding parts of the bundle`_

* `advanced configuration`_

* `go further`_


.. _installation: index.rst
.. _basic usage: usage.rst
.. _overriding parts of the bundle: overriding.rst
.. _advanced configuration: advanced-configuration.rst
.. _go further: further.rst

.. _Github: https://github.com/maximilienGilet/notification-bundle